package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;

import org.apache.commons.codec.digest.DigestUtils;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.directconnect.model.NewBGPPeer;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.AbortMultipartUploadRequest;
import com.amazonaws.services.s3.model.CompleteMultipartUploadRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PartETag;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.UploadPartRequest;


//�����ļ�
public class Main {
	private final static String bucketName = "zhu";
	private final static String folderPath = "D:\\download\\";
	private final static String accessKey = "FEA16476EE52A96FD9B6";
	private final static String secretKey = "WzFENDNBM0U1RjZGNTAwQzQ1N0VGQURBM0UzOEZC";
	private final static String serviceEndpoint = "http://scut.depts.bingosoft.net:29997";
	private static long partSize = 20 << 20;
	private final static String signingRegion = "";
	
	public static void main(String[] args) throws IOException {
		final BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey,secretKey);
		final ClientConfiguration ccfg = new ClientConfiguration().
				withUseExpectContinue(true);

		final EndpointConfiguration endpoint = new EndpointConfiguration(serviceEndpoint, signingRegion);

		final AmazonS3 s3 = AmazonS3ClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withClientConfiguration(ccfg)
                .withEndpointConfiguration(endpoint)
                .withPathStyleAccessEnabled(true)
                .build(); 
		
		
		System.out.println("����1��bucketͬ�������أ�����2�ѱ���ͬ����bucket");
		Scanner input=new Scanner(System.in);
		int n=input.nextInt();
		System.out.println(n);

		if(n==1) {
			bucket2Local(s3);
		}else if(n==2) {
			local2Bucket(s3);
		}
//		local2Bucket(s3);
	}
	
	public static void bucket2Local(AmazonS3 s3) throws IOException {
		
		ListObjectsV2Result result = s3.listObjectsV2(bucketName);
		List<S3ObjectSummary> objects = result.getObjectSummaries();
		
		ArrayList<String> pathList=getFiles(folderPath,new ArrayList<>());
		
		for (S3ObjectSummary os : objects) {
		//		    System.out.println("* " + os.getKey());
			final String keyName = os.getKey();
		    final String filePath = folderPath + keyName.replace("/", "\\");
		//		    System.out.println(filePath);
		    if(!filePath.endsWith("\\")) {
		    	//�����������ͬ�ļ������ļ�
			    if(pathList.contains(filePath)) {
			    	pathList.remove(filePath);
			    	String localEtag=calculateETag(filePath);
			    	//�ļ�������ͬ������
			    	if(os.getETag().equals(localEtag)) {
			    		System.out.println("continue");
			    		continue;
			    	}else {
			    		//�ļ����ݲ���ͬ������
			    		System.out.println("download1");
						if(os.getSize()<=partSize) downloadFile(s3, filePath, keyName);
						else downloadBigFile(s3, filePath, keyName);
			    	}
			    	
			    }else {
			    	//����û����ͬ�ļ�
			    	System.out.println("download2");
			    	if(os.getSize()<=partSize) downloadFile(s3, filePath, keyName);
					else downloadBigFile(s3, filePath, keyName);
			    }
			}
			
		}
		//���ض�����ļ�
		if(!pathList.isEmpty()) {
			try {
				for(String p:pathList) {
					System.out.println("delete");
		    		File file=new File(p);
		    		file.delete();
		    	}
			}catch (Exception e) {
				// TODO: handle exception
				System.out.println("ɾ���ļ���������");
		        e.printStackTrace();
			}
		}
		System.out.println("Done!");
	}
	
	public static void local2Bucket(AmazonS3 s3) {
		ArrayList<String> pathList=getFiles(folderPath,new ArrayList<>());
		ArrayList<String> keyList=new ArrayList<>();
		for(String p:pathList) {
			keyList.add(p.split("download\\\\")[1].replace("\\", "/"));
		}
		
		ListObjectsV2Result result = s3.listObjectsV2(bucketName);
		List<S3ObjectSummary> objects = result.getObjectSummaries();
		HashMap<String,String> bucketKeys = new HashMap<>();
		for (S3ObjectSummary os : objects) {
			bucketKeys.put(os.getKey().replace("\\", "/"),os.getETag());
		}
for(int i=0;i<pathList.size();i++) {
	String filePath=pathList.get(i);
	String keyName=keyList.get(i);
	//��������
	if(!bucketKeys.containsKey(keyName)) {
		System.out.format("Uploading %s to S3 bucket %s...\n", filePath, bucketName);
		System.out.println("upload1");
		if(new File(filePath).length()<=partSize)uploadFile(s3, filePath, keyName);
		else uploadBigFile(s3, filePath, keyName);
//				System.out.println(bucketKeys);
	}else if (!bucketKeys.get(keyName).equals(calculateETag(filePath))) {
		//�����޸�
		System.out.format("Uploading %s to S3 bucket %s...\n", filePath, bucketName);
		System.out.println("upload2");
		if(new File(filePath).length()<=partSize)uploadFile(s3, filePath, keyName);
		else uploadBigFile(s3, filePath, keyName);
//				System.out.println(bucketKeys);
	}else {
		System.out.println("continue");
	}
	bucketKeys.remove(keyName);
}
//����ɾ��
if(!bucketKeys.isEmpty()) {
	for(Entry<String, String> entry: bucketKeys.entrySet()) {
		System.out.println("delete");
		s3.deleteObject(bucketName,entry.getKey());
    }
}
		System.out.println("Done!");
	}
	
	public static ArrayList<String> getFiles(String folderPath,ArrayList<String> pList){
		File file = new File(folderPath);
		File[] fileList = file.listFiles();
		if(fileList==null) {
			return pList;
		}

		for (int i = 0; i < fileList.length; i++) {
			if(fileList[i].isDirectory()) {
				getFiles(fileList[i].getAbsolutePath(),pList);
			}
			if(fileList[i].isFile()) {//�ж��Ƿ�Ϊ�ļ�
		        pList.add(fileList[i].getAbsolutePath());
			}
		}
		return pList;
	}
	
	public static String calculateETag(String localFilePath) {
		File file = new File(localFilePath);
		String s = "";
		try {
			InputStream is = new FileInputStream(file);
			String digest = DigestUtils.md5Hex(is); // ����MD5ֵ
			s = digest;
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
	 }
	
	public static void downloadFile(AmazonS3 s3, String filePath, String keyName) throws IOException {
		System.out.println("downloadFile");
		File myPath=new File(filePath);
		if(!myPath.getParentFile().exists()) {
			myPath.getParentFile().mkdirs();
		}
//		final String keyName = Paths.get(filePath).getFileName().toString();

	    System.out.format("Downloading %s to S3 bucket %s...\n", keyName, bucketName);

	    S3ObjectInputStream s3is = null;
	    FileOutputStream fos = null;
	    try {
	    	S3Object o = s3.getObject(bucketName, keyName);
	    	s3is = o.getObjectContent();
	    	fos = new FileOutputStream(myPath);
	    	byte[] read_buf = new byte[64 * 1024];
	    	int read_len = 0;
	    	while ((read_len = s3is.read(read_buf)) > 0) {
	    		fos.write(read_buf, 0, read_len);
	    	}
	    } catch (AmazonServiceException e) {
	    	System.err.println(e.toString());
	    	System.exit(1);
	    } catch (IOException e) {
	    	System.err.println(e.getMessage());
	    	System.exit(1);
	    } finally {
	    	if (s3is != null) try { s3is.close(); } catch (IOException e) { }
	    	if (fos != null) try { fos.close(); } catch (IOException e) { }
	    }
	}

	public static void downloadBigFile(AmazonS3 s3, String filePath, String keyName) {
		System.out.println("downloadBigFile");
		File file = new File(filePath);
		
		S3Object o = null;
		
		S3ObjectInputStream s3is = null;
		FileOutputStream fos = null;
		
		try {
			// Step 1: Initialize.
			ObjectMetadata oMetaData = s3.getObjectMetadata(bucketName, keyName);
			final long contentLength = oMetaData.getContentLength();
			final GetObjectRequest downloadRequest = new GetObjectRequest(bucketName, keyName);

			fos = new FileOutputStream(file);

			// Step 2: Download parts.
			long filePosition = 0;
			for (int i = 1; filePosition < contentLength; i++) {
				// Last part can be less than 5 MB. Adjust part size.
				partSize = Math.min(partSize, contentLength - filePosition);

				// Create request to download a part.
				downloadRequest.setRange(filePosition, filePosition + partSize);
				o = s3.getObject(downloadRequest);

				// download part and save to local file.
				System.out.format("Downloading part %d\n", i);

				filePosition += partSize+1;
				s3is = o.getObjectContent();
				byte[] read_buf = new byte[64 * 1024];
				int read_len = 0;
				while ((read_len = s3is.read(read_buf)) > 0) {
					fos.write(read_buf, 0, read_len);
				}
			}

			// Step 3: Complete.
			System.out.println("Completing download");

			System.out.format("save %s to %s\n", keyName, filePath);
		} catch (Exception e) {
			System.err.println(e.toString());
			
			System.exit(1);
		} finally {
			if (s3is != null) try { s3is.close(); } catch (IOException e) { }
			if (fos != null) try { fos.close(); } catch (IOException e) { }
		}
	}
	
	public static void uploadFile(AmazonS3 s3, String filePath, String keyName) {
		System.out.println("uploadFile");
		final File file = new File(filePath);

        for (int i = 0; i < 2; i++) {
            try {
                s3.putObject(bucketName, keyName, file);
                break;
            } catch (AmazonServiceException e) {
                if (e.getErrorCode().equalsIgnoreCase("NoSuchBucket")) {
                    s3.createBucket(bucketName);
                    continue;
                }

                System.err.println(e.toString());
                System.exit(1);
            } catch (AmazonClientException e) {
                try {
                    // detect bucket whether exists
                    s3.getBucketAcl(bucketName);
                } catch (AmazonServiceException ase) {
                    if (ase.getErrorCode().equalsIgnoreCase("NoSuchBucket")) {
                        s3.createBucket(bucketName);
                        continue;
                    }
                } catch (Exception ignore) {
                }

                System.err.println(e.toString());
                System.exit(1);
            }
        }
	}
	
	public static void uploadBigFile(AmazonS3 s3, String filePath, String keyName) {
		System.out.println("uploadBigFile");
		ArrayList<PartETag> partETags = new ArrayList<PartETag>();
		File file = new File(filePath);
		long contentLength = file.length();
		String uploadId = null;
		try {
			// Step 1: Initialize.
			InitiateMultipartUploadRequest initRequest = new InitiateMultipartUploadRequest(bucketName, keyName);
			uploadId = s3.initiateMultipartUpload(initRequest).getUploadId();
			System.out.format("Created upload ID was %s\n", uploadId);

			// Step 2: Upload parts.
			long filePosition = 0;
			for (int i = 1; filePosition < contentLength; i++) {
				// Last part can be less than 5 MB. Adjust part size.
				partSize = Math.min(partSize, contentLength - filePosition);

				// Create request to upload a part.
				UploadPartRequest uploadRequest = new UploadPartRequest()
						.withBucketName(bucketName)
						.withKey(keyName)
						.withUploadId(uploadId)
						.withPartNumber(i)
						.withFileOffset(filePosition)
						.withFile(file)
						.withPartSize(partSize);

				// Upload part and add response to our list.
				System.out.format("Uploading part %d\n", i);
				partETags.add(s3.uploadPart(uploadRequest).getPartETag());

				filePosition += partSize;
			}

			// Step 3: Complete.
			System.out.println("Completing upload");
			CompleteMultipartUploadRequest compRequest = new CompleteMultipartUploadRequest(bucketName, keyName, uploadId, partETags);
			s3.completeMultipartUpload(compRequest);
		} catch (Exception e) {
			System.err.println(e.toString());
			if (uploadId != null && !uploadId.isEmpty()) {
				// Cancel when error occurred
				System.out.println("Aborting upload");
				s3.abortMultipartUpload(new AbortMultipartUploadRequest(bucketName, keyName, uploadId));
			}
			System.exit(1);
		}
	}
}